public class Pedido{
	
	private Produto produtos[];
		
	public Pedido(int tamanho){
			
		this.produtos = new Produto[tamanho];
	}
	public void setProduto(int indice, double valor){
		
		produtos[i] = valor;
	}			
}

