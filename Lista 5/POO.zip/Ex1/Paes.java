public class Paes extends Produto{
	public Paes(double quantidade,double preco){
		
		super(quantidade,preco);
	}
}

