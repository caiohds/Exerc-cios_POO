public class Frios extends Produto{
	public Frios(double quantidade,double preco){
		
		super(quantidade,preco);
	}
}

